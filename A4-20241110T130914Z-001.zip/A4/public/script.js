console.log("Static website loaded successfully!");
